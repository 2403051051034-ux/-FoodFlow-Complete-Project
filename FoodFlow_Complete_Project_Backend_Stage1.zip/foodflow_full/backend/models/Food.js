const mongoose=require('mongoose');
module.exports=mongoose.model('Food',new mongoose.Schema({name:{type:String,required:true,trim:true},description:String,price:{type:Number,required:true,min:0},category:{type:mongoose.Schema.Types.ObjectId,ref:'Category',required:true},image:String,emoji:String,available:{type:Boolean,default:true}},{timestamps:true}));
