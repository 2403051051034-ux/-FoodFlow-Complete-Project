const mongoose=require('mongoose');
module.exports=mongoose.model('Cart',new mongoose.Schema({user:{type:mongoose.Schema.Types.ObjectId,ref:'User',unique:true,required:true},items:[{food:{type:mongoose.Schema.Types.ObjectId,ref:'Food'},quantity:{type:Number,min:1},price:{type:Number,min:0}}]},{timestamps:true}));
