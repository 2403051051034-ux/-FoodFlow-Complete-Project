const mongoose=require('mongoose');
module.exports=mongoose.model('Delivery',new mongoose.Schema({order:{type:mongoose.Schema.Types.ObjectId,ref:'Order',required:true,unique:true},deliveryPerson:{type:mongoose.Schema.Types.ObjectId,ref:'User'},status:{type:String,enum:['Assigned','Out for delivery','Delivered'],default:'Assigned'},assignedAt:Date,deliveredAt:Date},{timestamps:true}));
