# FoodFlow Backend

Express + MongoDB + JWT backend for the FoodFlow food-ordering website.

## Modules
- Authentication and role-based access: customer, admin, delivery
- Category CRUD
- Food CRUD and search
- Cart CRUD
- Order creation and tracking
- Admin order status and delivery assignment
- Delivery status updates
- MongoDB persistence

## Local setup
1. Install Node.js.
2. Copy `.env.example` to `.env`.
3. Put your MongoDB Atlas connection string in `MONGODB_URI`.
4. Set a strong `JWT_SECRET`.
5. Run `npm install`.
6. Run `npm run seed` for sample data.
7. Run `npm start`.
8. Test `GET /api/health`.

Seed accounts:
- Admin: admin@foodflow.com / Admin@123
- Delivery: delivery@foodflow.com / Delivery@123

Change these passwords before any real deployment.
