const router=require('express').Router();const Category=require('../models/Category');const {protect,authorize}=require('../middleware/auth');
router.get('/',async(req,res,next)=>{try{res.json({success:true,data:await Category.find({active:true}).sort('name')})}catch(e){next(e)}});
router.post('/',protect,authorize('admin'),async(req,res,next)=>{try{res.status(201).json({success:true,data:await Category.create(req.body)})}catch(e){next(e)}});
router.put('/:id',protect,authorize('admin'),async(req,res,next)=>{try{const x=await Category.findByIdAndUpdate(req.params.id,req.body,{new:true,runValidators:true});if(!x)return res.status(404).json({success:false,message:'Category not found'});res.json({success:true,data:x})}catch(e){next(e)}});
router.delete('/:id',protect,authorize('admin'),async(req,res,next)=>{try{const x=await Category.findByIdAndUpdate(req.params.id,{active:false},{new:true});if(!x)return res.status(404).json({success:false,message:'Category not found'});res.json({success:true,message:'Category deleted'})}catch(e){next(e)}});
module.exports=router;
