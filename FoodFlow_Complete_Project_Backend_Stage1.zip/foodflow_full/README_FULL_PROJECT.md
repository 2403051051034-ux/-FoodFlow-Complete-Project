# FoodFlow Complete Minor Project

This package contains the existing FoodFlow frontend plus a new Express/MongoDB backend scaffold.

Frontend: `food_project_build/`
Backend: `backend/`

The current frontend still uses localStorage. The next integration step is to replace its demo data/localStorage operations with calls to the backend API after the backend is deployed.

Recommended deployment architecture:
Frontend -> Netlify
Backend -> Node/Express hosting
Database -> MongoDB Atlas

The backend includes the functionality needed to support the project's practicals: authentication, roles, category/food CRUD, cart, orders, delivery, API testing and database persistence.
