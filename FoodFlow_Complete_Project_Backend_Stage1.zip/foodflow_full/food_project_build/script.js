const foods=[
{id:1,name:'Margherita Pizza',cat:'Pizza',price:249,emoji:'🍕'},
{id:2,name:'Veg Burger',cat:'Burgers',price:149,emoji:'🍔'},
{id:3,name:'Paneer Tikka',cat:'Indian',price:229,emoji:'🍢'},
{id:4,name:'Masala Dosa',cat:'Indian',price:139,emoji:'🥞'},
{id:5,name:'Chicken Biryani',cat:'Biryani',price:299,emoji:'🍛'},
{id:6,name:'French Fries',cat:'Sides',price:99,emoji:'🍟'},
{id:7,name:'Chocolate Shake',cat:'Drinks',price:129,emoji:'🥤'},
{id:8,name:'Veg Noodles',cat:'Chinese',price:189,emoji:'🍜'}
];
let active='All';
let cart=JSON.parse(localStorage.getItem('foodflowCart')||'[]');
let lastOrder=JSON.parse(localStorage.getItem('foodflowOrder')||'null');
const cats=['All',...new Set(foods.map(f=>f.cat))];
const $=id=>document.getElementById(id);

function money(n){return '₹'+n.toLocaleString('en-IN')}
function save(){localStorage.setItem('foodflowCart',JSON.stringify(cart))}
function showToast(msg){const t=$('toast');t.textContent=msg;t.classList.add('show');clearTimeout(window.toastTimer);window.toastTimer=setTimeout(()=>t.classList.remove('show'),2200)}
function renderCats(){$('categories').innerHTML=cats.map(c=>`<button class="chip ${c===active?'active':''}" data-cat="${c}">${c}</button>`).join('')}
function renderMenu(){const q=$('search').value.trim().toLowerCase();const arr=foods.filter(f=>(active==='All'||f.cat===active)&&f.name.toLowerCase().includes(q));$('menuGrid').innerHTML=arr.length?arr.map(f=>`<article class="food"><div class="food-img">${f.emoji}</div><h3>${f.name}</h3><p>${f.cat} · Freshly prepared</p><div class="food-bottom"><b>${money(f.price)}</b><button class="add" data-add="${f.id}">Add</button></div></article>`).join(''):`<div class="empty grid-empty">No food items found.</div>`}
function add(id){const f=foods.find(x=>x.id===Number(id));if(!f)return;const item=cart.find(x=>x.id===f.id);item?item.qty++:cart.push({...f,qty:1});save();renderCart();openCart();showToast(`${f.name} added to cart`)}
function changeQty(id,delta){const item=cart.find(x=>x.id===Number(id));if(!item)return;item.qty+=delta;if(item.qty<=0)cart=cart.filter(x=>x.id!==item.id);save();renderCart()}
function renderCart(){const count=cart.reduce((a,x)=>a+x.qty,0),total=cart.reduce((a,x)=>a+x.price*x.qty,0);$('cartCount').textContent=count;$('cartTotal').textContent=money(total);$('cartItems').innerHTML=cart.length?cart.map(x=>`<div class="cart-row"><div><b>${x.emoji} ${x.name}</b><small>${money(x.price)} each</small><div class="qty"><button data-minus="${x.id}">−</button><span>${x.qty}</span><button data-plus="${x.id}">+</button></div></div><b>${money(x.price*x.qty)}</b></div>`).join(''):`<div class="empty">Your cart is empty.<br><small>Add a food item from the menu.</small></div>`}
function openCart(){$('cart').classList.add('open');$('overlay').classList.add('open')}
function closeCart(){$('cart').classList.remove('open');$('overlay').classList.remove('open')}
function openModal(){if(!cart.length){showToast('Add food items to your cart first');return} $('checkoutModal').classList.remove('hidden')}
function closeModal(){$('checkoutModal').classList.add('hidden')}
function createOrder(){const name=$('customerName').value.trim(),phone=$('customerPhone').value.trim(),address=$('customerAddress').value.trim();if(!name||!/^\d{10}$/.test(phone)||!address){showToast('Please enter name, 10-digit phone and address');return}const total=cart.reduce((a,x)=>a+x.price*x.qty,0);lastOrder={id:'FOOD'+Math.floor(1000+Math.random()*9000),name,phone,address,total,items:cart.map(x=>({...x})),status:'Placed',createdAt:new Date().toISOString()};localStorage.setItem('foodflowOrder',JSON.stringify(lastOrder));cart=[];save();closeModal();closeCart();renderCart();renderOrder();renderAdmin();renderDelivery();showToast(`Order #${lastOrder.id} placed successfully`);$('orders').scrollIntoView({behavior:'smooth'})}
function renderOrder(){if(!lastOrder){$('orderEmpty').classList.remove('hidden');$('orderCard').classList.add('hidden');return}$('orderEmpty').classList.add('hidden');$('orderCard').classList.remove('hidden');$('orderNumber').textContent=`Order #${lastOrder.id}`;$('orderStatus').textContent=`${lastOrder.status} · ${lastOrder.name}`;const states=['Placed','Confirmed','Preparing','Out for delivery','Delivered'];states.forEach((s,i)=>{$('s'+(i+1)).classList.toggle('done',states.indexOf(lastOrder.status)>i);$('s'+(i+1)).classList.toggle('active',lastOrder.status===s)})}
function renderAdmin(){if(!lastOrder){$('adminOrders').innerHTML='<tr><td colspan="5" class="muted-cell">No orders yet. Place an order as Customer.</td></tr>';return}$('adminOrders').innerHTML=`<tr><td>#${lastOrder.id}</td><td>${lastOrder.name}</td><td>${money(lastOrder.total)}</td><td><span class="badge">${lastOrder.status}</span></td><td><button class="mini" id="confirmAdmin">Confirm</button></td></tr>`;$('orderMetric').textContent='1';$('confirmAdmin').onclick=()=>updateStatus('Confirmed')}
function renderDelivery(){if(!lastOrder||lastOrder.status==='Delivered'){$('deliveryEmpty').classList.remove('hidden');$('deliveryCard').classList.add('hidden');return}$('deliveryEmpty').classList.add('hidden');$('deliveryCard').classList.remove('hidden');$('deliveryOrder').textContent='#'+lastOrder.id;$('deliveryTotal').textContent=money(lastOrder.total);$('deliveryBtn').textContent=lastOrder.status==='Out for delivery'?'Mark Delivered':'Mark Out for delivery';$('deliveryBtn').onclick=()=>updateStatus(lastOrder.status==='Out for delivery'?'Delivered':'Out for delivery')}
function updateStatus(status){if(!lastOrder)return;lastOrder.status=status;localStorage.setItem('foodflowOrder',JSON.stringify(lastOrder));renderOrder();renderAdmin();renderDelivery();showToast(`Order status updated: ${status}`)}

$('browseBtn').onclick=()=>$('menu').scrollIntoView({behavior:'smooth'});
$('cartBtn').onclick=openCart;$('closeCart').onclick=closeCart;$('overlay').onclick=closeCart;$('checkoutBtn').onclick=openModal;$('closeModal').onclick=closeModal;$('confirmOrder').onclick=createOrder;
$('search').oninput=renderMenu;
$('categories').addEventListener('click',e=>{const b=e.target.closest('[data-cat]');if(!b)return;active=b.dataset.cat;renderCats();renderMenu()});
$('menuGrid').addEventListener('click',e=>{const b=e.target.closest('[data-add]');if(b)add(b.dataset.add)});
$('cartItems').addEventListener('click',e=>{const p=e.target.closest('[data-plus]'),m=e.target.closest('[data-minus]');if(p)changeQty(p.dataset.plus,1);if(m)changeQty(m.dataset.minus,-1)});
document.querySelector('.hero-card').addEventListener('click',e=>{const b=e.target.closest('[data-add]');if(b)add(b.dataset.add)});
$('role').addEventListener('change',e=>{const target=e.target.value==='Admin'?'admin':e.target.value==='Delivery'?'delivery':'menu';document.getElementById(target).scrollIntoView({behavior:'smooth'});showToast(`${e.target.value} view selected`)});
$('checkoutModal').addEventListener('click',e=>{if(e.target===$('checkoutModal'))closeModal()});

renderCats();renderMenu();renderCart();renderOrder();renderAdmin();renderDelivery();
