# FoodFlow — Food Ordering Website

A responsive academic prototype derived from the Food Ordering Website Software Engineering project.

## Supported flows
- Customer registration/login concept
- Food categories, search and food details
- Cart add/update/remove concept
- Checkout and order creation
- Order tracking
- Admin category/food/order management dashboard concept
- Delivery assignment and status update concept
- Role-aware UI: Customer, Admin, Delivery

## Software Engineering alignment
The accompanying practical document models DFD Level 0/1/2, data dictionary, structure chart, use-case, class, state, collaboration, sequence and activity diagrams, coding standards, test cases, testing-tool comparison, security and quality requirements.

## Run
Open `index.html` in a modern browser. The demo is client-side and uses in-memory sample data; it is structured to be connected to a MERN REST API for a full implementation.
